# JUNIOR APP — Flutter starter

This is the first starter version of JUNIOR APP, an all-in-one Android fitness app.

## Included in this starter
- Dark navy and lime-green app design
- Home dashboard
- Sample weekly training timetable
- Working stopwatch with start, pause, and reset
- Progress screen mock-up
- Settings screen with planned reminders

## Not yet implemented
- GPS tracking and distance calculation
- Persistent workout history
- Scheduled notifications
- Fitness profile and selectable test protocols

## Build an APK
This source folder needs Flutter and the Android build toolchain to compile. Because you have an Android phone only, the easiest next route is to use a cloud development/build service from your phone:
1. Create or sign in to a Git repository service in your mobile browser.
2. Upload these project files, preserving `pubspec.yaml` and the `lib/main.dart` path.
3. Connect the repository to a Flutter-compatible cloud build service.
4. Configure the build command as `flutter pub get` followed by `flutter build apk --release`.
5. Download the generated APK to your phone and install it. Android may ask you to allow installation from that source.

Cloud build services may require an account and some may have usage limits. Do not install APKs from unknown third-party sources.

## Local build (if you later get access to a computer)
Install Flutter and Android Studio, then run:
```bash
flutter pub get
flutter run
flutter build apk --release
```

This is a starter source project, not a compiled APK. The first version is a UI prototype; GPS, reminders, and saved workout history are future implementation steps.
