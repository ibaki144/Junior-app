import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const JuniorApp());

const lime = Color(0xFFB8F34A);
const ink = Color(0xFF101B2A);
const panel = Color(0xFF1D2B3D);

class JuniorApp extends StatelessWidget {
  const JuniorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JUNIOR APP',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: lime,
          brightness: Brightness.dark,
          surface: panel,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: ink,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: panel,
          indicatorColor: lime.withValues(alpha: 0.20),
          labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          ),
        ),
        useMaterial3: true,
      ),
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int index = 0;

  final pages = const [
    HomeScreen(),
    TrainingScreen(),
    RunningScreen(),
    ProgressScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Plan'),
          NavigationDestination(icon: Icon(Icons.timer_outlined), selectedIcon: Icon(Icons.timer), label: 'Run'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Settings'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(color: lime, borderRadius: BorderRadius.circular(15)),
              child: const Icon(Icons.fitness_center, color: ink, size: 28),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('JUNIOR APP', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1)),
                  Text('TRAIN SMART. GET STRONGER.', style: TextStyle(color: lime, fontSize: 10, letterSpacing: 1.1)),
                ],
              ),
            ),
            const Icon(Icons.notifications_none, size: 28),
          ],
        ),
        const SizedBox(height: 28),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(24)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('YOUR FITNESS JOURNEY', style: TextStyle(color: lime, fontSize: 11, letterSpacing: 1.2)),
              const SizedBox(height: 8),
              const Text('Every session counts.', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Build endurance, stay consistent, and track your progress.', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 20),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: ink, minimumSize: const Size.fromHeight(50)),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RunningScreen())),
                icon: const Icon(Icons.play_arrow),
                label: const Text('START A WORKOUT', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const SectionTitle('QUICK ACCESS'),
        const SizedBox(height: 12),
        const Row(
          children: [
            Expanded(child: QuickCard(icon: Icons.calendar_month, title: 'Training plan', subtitle: 'Weekly timetable')),
            SizedBox(width: 12),
            Expanded(child: QuickCard(icon: Icons.timer, title: 'Run timer', subtitle: 'Time your session')),
          ],
        ),
        const SizedBox(height: 12),
        const Row(
          children: [
            Expanded(child: QuickCard(icon: Icons.track_changes, title: 'Fitness tests', subtitle: 'Prepare for a goal')),
            SizedBox(width: 12),
            Expanded(child: QuickCard(icon: Icons.show_chart, title: 'Progress', subtitle: 'Review activity')),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('TODAY’S SUGGESTION'),
        const SizedBox(height: 10),
        const WorkoutTile(time: '07:00 AM', title: 'Easy endurance run', detail: '20 minutes · Comfortable pace', icon: Icons.directions_run),
        const WorkoutTile(time: '06:00 PM', title: 'Mobility and stretching', detail: '10 minutes · Recovery', icon: Icons.self_improvement),
        const SizedBox(height: 10),
        const Text('Starter version: your workout data is not yet saved between app sessions.', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ],
    );
  }
}

class TrainingScreen extends StatelessWidget {
  const TrainingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const days = [
      ('MONDAY', 'Easy run', '20 min · Comfortable pace', Icons.directions_run),
      ('TUESDAY', 'Strength workout', '20 min · Full body', Icons.fitness_center),
      ('WEDNESDAY', 'Interval training', 'Warm up, short intervals, cool down', Icons.speed),
      ('THURSDAY', 'Recovery', 'Mobility and stretching', Icons.self_improvement),
      ('FRIDAY', 'Endurance session', 'Build gradually at a steady pace', Icons.route),
      ('SATURDAY', 'Fitness test practice', 'Practice only at a suitable level', Icons.flag),
      ('SUNDAY', 'Rest day', 'Recover, hydrate, and sleep well', Icons.bedtime),
    ];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ScreenHeading('Training plan', 'A sample weekly timetable'),
        const SizedBox(height: 16),
        ...days.map((d) => WorkoutTile(time: d.$1, title: d.$2, detail: d.$3, icon: d.$4)),
        const SizedBox(height: 12),
        const Text('Adjust sessions to your current fitness level. Stop if you feel chest pain, faintness, or unusual shortness of breath.', style: TextStyle(color: Colors.white60, fontSize: 12)),
      ],
    );
  }
}

class RunningScreen extends StatefulWidget {
  const RunningScreen({super.key});

  @override
  State<RunningScreen> createState() => _RunningScreenState();
}

class _RunningScreenState extends State<RunningScreen> {
  Timer? ticker;
  int seconds = 0;
  bool running = false;

  String get timeText {
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final s = seconds % 60;
    return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  void toggle() {
    if (running) {
      ticker?.cancel();
      setState(() => running = false);
    } else {
      ticker = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => seconds++);
      });
      setState(() => running = true);
    }
  }

  void reset() {
    ticker?.cancel();
    setState(() {
      seconds = 0;
      running = false;
    });
  }

  @override
  void dispose() {
    ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ScreenHeading('Run timer', 'Time your training session'),
        const SizedBox(height: 28),
        Container(
          padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 18),
          decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(28)),
          child: Column(
            children: [
              const Icon(Icons.timer, color: lime, size: 40),
              const SizedBox(height: 16),
              Text(timeText, style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800, fontFeatures: [])),
              const SizedBox(height: 8),
              Text(running ? 'SESSION IN PROGRESS' : 'READY WHEN YOU ARE', style: const TextStyle(color: Colors.white60, fontSize: 11, letterSpacing: 1)),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: ink, minimumSize: const Size.fromHeight(50)),
                      onPressed: toggle,
                      icon: Icon(running ? Icons.pause : Icons.play_arrow),
                      label: Text(running ? 'PAUSE' : 'START'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(110, 50)),
                    onPressed: reset,
                    icon: const Icon(Icons.refresh),
                    label: const Text('RESET'),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const QuickCard(icon: Icons.location_on_outlined, title: 'GPS distance tracking', subtitle: 'Planned next: location permission, distance, and pace.'),
        const SizedBox(height: 12),
        const QuickCard(icon: Icons.save_outlined, title: 'Save workout', subtitle: 'Planned next: store sessions and show them in Progress.'),
      ],
    );
  }
}

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ScreenHeading('Your progress', 'Your fitness journey at a glance'),
        const SizedBox(height: 18),
        const Row(
          children: [
            Expanded(child: MetricCard(value: '0', label: 'Workouts')),
            SizedBox(width: 10),
            Expanded(child: MetricCard(value: '0.0 km', label: 'Distance')),
          ],
        ),
        const SizedBox(height: 10),
        const Row(
          children: [
            Expanded(child: MetricCard(value: '00:00', label: 'Run time')),
            SizedBox(width: 10),
            Expanded(child: MetricCard(value: '0', label: 'Goals reached')),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('WEEKLY ACTIVITY'),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20)),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Your activity chart will appear here', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Once workout history is saved, this section can show weekly running distance, duration, and consistency.', style: TextStyle(color: Colors.white60)),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ActivityBar(day: 'M', height: 24),
                  ActivityBar(day: 'T', height: 42),
                  ActivityBar(day: 'W', height: 30),
                  ActivityBar(day: 'T', height: 55),
                  ActivityBar(day: 'F', height: 36),
                  ActivityBar(day: 'S', height: 48),
                  ActivityBar(day: 'S', height: 18),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text('Progress numbers are placeholders in this starter version.', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ],
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ScreenHeading('Settings', 'Make JUNIOR APP work for you'),
        const SizedBox(height: 16),
        const SettingsTile(icon: Icons.notifications_active_outlined, title: 'Daily workout reminders', subtitle: 'Notification scheduling will be added next'),
        const SettingsTile(icon: Icons.flag_outlined, title: 'Fitness test goals', subtitle: 'Choose a test and target time in a future update'),
        const SettingsTile(icon: Icons.person_outline, title: 'Fitness profile', subtitle: 'Profile setup is planned'),
        const SettingsTile(icon: Icons.privacy_tip_outlined, title: 'Privacy and permissions', subtitle: 'GPS will only be enabled after permission is granted'),
        const SizedBox(height: 20),
        const Text('JUNIOR APP · Starter v1.0', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
      ],
    );
  }
}

class ScreenHeading extends StatelessWidget {
  final String title;
  final String subtitle;
  const ScreenHeading(this.title, this.subtitle, {super.key});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      Text(subtitle, style: const TextStyle(color: Colors.white60)),
    ],
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 1.2, color: lime));
}

class QuickCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const QuickCard({required this.icon, required this.title, required this.subtitle, super.key});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: lime, size: 25),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 11)),
      ],
    ),
  );
}

class WorkoutTile extends StatelessWidget {
  final String time;
  final String title;
  final String detail;
  final IconData icon;
  const WorkoutTile({required this.time, required this.title, required this.detail, required this.icon, super.key});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Row(
      children: [
        Container(width: 44, height: 44, decoration: BoxDecoration(color: lime.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: lime)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(time.toUpperCase(), style: const TextStyle(color: lime, fontSize: 10, letterSpacing: 1)),
          const SizedBox(height: 3),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text(detail, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ])),
      ],
    ),
  );
}

class MetricCard extends StatelessWidget {
  final String value;
  final String label;
  const MetricCard({required this.value, required this.label, super.key});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(17),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: lime)),
      const SizedBox(height: 5),
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
    ]),
  );
}

class ActivityBar extends StatelessWidget {
  final String day;
  final double height;
  const ActivityBar({required this.day, required this.height, super.key});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Container(width: 18, height: height, decoration: BoxDecoration(color: lime, borderRadius: BorderRadius.circular(6))),
      const SizedBox(height: 8),
      Text(day, style: const TextStyle(color: Colors.white60, fontSize: 11)),
    ],
  );
}

class SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const SettingsTile({required this.icon, required this.title, required this.subtitle, super.key});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      Icon(icon, color: lime, size: 25),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ])),
    ]),
  );
}
